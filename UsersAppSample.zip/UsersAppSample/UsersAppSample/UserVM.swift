//
//  UserVM.swift
//  UsersApp
//
//  Created by Azhaan Hasib on 18/10/25.
//

import Foundation
import SwiftUI




@MainActor
class UserVM: ObservableObject {
    
    @Published private(set) var model: [Users]?
    @Published  var errorMsg: String?
    
    var repo: UserRepoHandler
    
    init(repo: UserRepoHandler) {
        self.repo = repo
    }
    
    func getUsers() async  {
        do {
            let users =  try await repo.fetchUsers()
            model = users
        }
        catch {
            self.errorMsg = error.localizedDescription
        }
        
        
    }
    
}


protocol UserRepoHandler {
    
    func fetchUsers() async throws -> [Users]?
}


class UserRepo: UserRepoHandler {
    
    var deocehandler: DecoderHandler
    var networkHandler: NetworkHandler
    
    init(deocehandler: DecoderHandler, networkhabdler: NetworkHandler) {
        self.deocehandler = deocehandler
        self.networkHandler = networkhabdler
    }
    
    
    func fetchUsers() async throws -> [Users]? {
        guard let request  =  UsersEndpoint.userList.urlRequest else { return  nil }
        
        let result = await networkHandler.fetchData(urlRequest: request).flatMap { data in
            deocehandler.deocdeData(data: data ?? Data(), type: [Users].self)
        }
        switch result {
        case .success(let users):
            return users
        case .failure(let err):
            throw err
        }
        
    }
        
}


protocol EndPoint {
    
    var baseUrl: String {get}
    var endUrl: String {get}
    
}

extension EndPoint {
    
    var urlRequest: URLRequest? {
            guard let url = URL(string: baseUrl + endUrl) else { return nil }
            return URLRequest(url: url)
    }
}

enum UsersEndpoint: EndPoint {
    
    
    case userList
    
    
    var baseUrl: String {
        
        return "https://fake-json-api.mock.beeceptor.com/"
    }
    
    var endUrl: String {
        
        switch self {
            
        case .userList:
            return "users"
            
        }
        
       
    }
    
    
}
