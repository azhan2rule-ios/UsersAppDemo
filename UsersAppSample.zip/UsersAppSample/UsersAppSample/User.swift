//
//  User.swift
//  UsersApp
//
//  Created by Azhaan Hasib on 18/10/25.
//

import Foundation


struct Users: Codable {
    let name: String
    let company: String
    let username: String
    let email: String
    let address: String
    let zip: String
    let state: String
    let country: String
    let phone: String
    let photo: String
    let id: Int

    enum CodingKeys: String, CodingKey {
        case name
        case company
        case username
        case email
        case address
        case zip
        case state
        case country
        case phone
        case photo
        case id
    }

    init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decode(String.self, forKey: .name)
        self.company = try container.decode(String.self, forKey: .company)
        self.username = try container.decode(String.self, forKey: .username)
        self.email = try container.decode(String.self, forKey: .email)
        self.address = try container.decode(String.self, forKey: .address)
        self.zip = try container.decode(String.self, forKey: .zip)
        self.state = try container.decode(String.self, forKey: .state)
        self.country = try container.decode(String.self, forKey: .country)
        self.phone = try container.decode(String.self, forKey: .phone)
        self.photo = try container.decode(String.self, forKey: .photo)
        self.id = try container.decode(Int.self, forKey: .id)
    }
}

