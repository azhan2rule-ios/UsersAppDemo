//
//  UserListView.swift
//  UsersApp
//
//  Created by Azhaan Hasib on 18/10/25.
//

import SwiftUI


struct UserListView: View {
    
    @StateObject var vm = UserVM(repo: UserRepo(deocehandler: CustomDecoder(), networkhabdler: Network()))
    
    var body: some View {
        NavigationStack { // Or NavigationView if targeting earlier SwiftUI versions
            VStack {
                if let error = vm.errorMsg {
                    Text(error)
                        .foregroundColor(.red)
                        .padding()
                }

                List(vm.model ?? [], id: \.id) { user in
                    NavigationLink(destination: UserDetailView(userDetails: user)) {
                        VStack(alignment: .leading) {
                            Text(user.username)
                        }
                    }
                }
            }
            .task {
                await vm.getUsers()
            }
            .navigationTitle("Users")
        }
    }
}

