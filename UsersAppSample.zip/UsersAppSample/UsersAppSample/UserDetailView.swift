//
//  UserDetailView.swift
//  UsersAppSample
//
//  Created by Azhaan Hasib on 18/10/25.
//

import SwiftUI

import SwiftUI

struct UserDetailView: View {
    var userDetails: Users
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Username: \(userDetails.username)")
            Text("Name: \(userDetails.name)")
            Text("Email: \(userDetails.email)")
            Text("Phone: \(userDetails.phone)")
        }
        .padding()
        .navigationTitle("User Detail")
    }
}


