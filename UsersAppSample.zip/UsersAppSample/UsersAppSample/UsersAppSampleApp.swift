//
//  UsersAppSampleApp.swift
//  UsersAppSample
//
//  Created by Azhaan Hasib on 18/10/25.
//

import SwiftUI

@main
struct UsersAppSampleApp: App {
    var body: some Scene {
        WindowGroup {
            UserListView()
        }
    }
}
