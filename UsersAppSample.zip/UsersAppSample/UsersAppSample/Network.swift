//
//  Network.swift
//  UsersApp
//
//  Created by Azhaan Hasib on 18/10/25.
//

import Foundation



protocol NetworkHandler {
    
    func fetchData(urlRequest: URLRequest) async -> Result<Data?, Error>
}

protocol DecoderHandler {
    
    
    func deocdeData<T: Codable>(data: Data, type: T.Type) -> Result<T?, Error>
}





class Network: NetworkHandler {
    
    
    func fetchData(urlRequest: URLRequest) async -> Result<Data?, Error>{
        
        do {
            let (data, _)  = try  await URLSession.shared.data(for: urlRequest)
            
            return .success(data)
        }
        catch {
            return .failure(error)
        }
                
        
    }
}


class CustomDecoder: DecoderHandler {
    
    
    func deocdeData<T: Codable>(data: Data, type: T.Type)   -> Result<T?, Error>  {
        
        do {
            let decodedData = try JSONDecoder().decode(type.self, from: data)
            
            return .success(decodedData)
        }
        catch {
            
            return .failure(error)
        }
    }
}
