//
//  UsersAppSampleTests.swift
//  UsersAppSampleTests
//
//  Created by Azhaan Hasib on 18/10/25.
//

import XCTest
@testable import UsersAppSample



final class UsersAppTests: XCTestCase {
    
    
    func testUsersData () async  throws {
        
            guard let url = Bundle.main.url(forResource: "users", withExtension: "json") else {
                return
            }
            let data = try Data(contentsOf: url)
            let modekedDecoder = MockDecoder()
            let mockedNetwork = MockNetwork()
            mockedNetwork.data = data
            let repo = UserRepo(deocehandler: modekedDecoder, networkhabdler: mockedNetwork)
            let model =  try await repo.fetchUsers()
            XCTAssertNotNil(model)
            XCTAssertEqual(model?.count ?? 0 , 10)
            XCTAssertEqual(model?.first?.id, 1)
            XCTAssertEqual(model?.first?.name ?? "", "Fernando Grimes")
            XCTAssertEqual(model?.first?.company ?? "", "Quitzon Group")
            XCTAssertEqual(model?.first?.username ?? "", "Torrance_McLaughlin50")
            XCTAssertEqual(model?.first?.email ?? "", "Wellington_Franecki55@hotmail.com")
            XCTAssertEqual(model?.first?.address ?? "", "4152 DuBuque Center")
            XCTAssertEqual(model?.first?.zip ?? "", "62064")
            XCTAssertEqual(model?.first?.state ?? "", "New Mexico")
            XCTAssertEqual(model?.first?.country ?? "", "Palestine")
            XCTAssertEqual(model?.first?.phone ?? "", "941-682-8250 x07449")
            XCTAssertEqual(model?.first?.photo ?? "", "https://json-server.dev/ai-profiles/90.png")

    }
    

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}


class MockNetwork: NetworkHandler {
    
    var data: Data?

    func fetchData(urlRequest: URLRequest) async -> Result<Data?, any Error> {
        return .success(data)
    }
    
}


class MockDecoder: DecoderHandler {
    
    func deocdeData<T: Codable>(data: Data, type: T.Type) -> Result<T?, any Error>  {
        do {
            let decodedData = try JSONDecoder().decode(type.self, from: data)
            
            return .success(decodedData)
        }
        catch {
            
            return .failure(error)
        }
    }
}
